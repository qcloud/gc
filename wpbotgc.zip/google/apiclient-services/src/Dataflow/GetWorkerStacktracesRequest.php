<?php
/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace Google\Service\Dataflow;

class GetWorkerStacktracesRequest extends \Google\Model
{
  /**
   * The worker for which to get stacktraces. The returned stacktraces will be
   * for the SDK harness running on this worker.
   *
   * @var string
   */
  public $workerId;

  /**
   * The worker for which to get stacktraces. The returned stacktraces will be
   * for the SDK harness running on this worker.
   *
   * @param string $workerId
   */
  public function setWorkerId($workerId)
  {
    $this->workerId = $workerId;
  }
  /**
   * @return string
   */
  public function getWorkerId()
  {
    return $this->workerId;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(GetWorkerStacktracesRequest::class, 'Google_Service_Dataflow_GetWorkerStacktracesRequest');
