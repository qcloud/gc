<?php
/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace Google\Service\Dataflow;

class ReportedParallelism extends \Google\Model
{
  /**
   * Specifies whether the parallelism is infinite. If true, "value" is ignored.
   * Infinite parallelism means the service will assume that the work item can
   * always be split into more non-empty work items by dynamic splitting. This
   * is a work-around for lack of support for infinity by the current JSON-based
   * Java RPC stack.
   *
   * @var bool
   */
  public $isInfinite;
  /**
   * Specifies the level of parallelism in case it is finite.
   *
   * @var 
   */
  public $value;

  /**
   * Specifies whether the parallelism is infinite. If true, "value" is ignored.
   * Infinite parallelism means the service will assume that the work item can
   * always be split into more non-empty work items by dynamic splitting. This
   * is a work-around for lack of support for infinity by the current JSON-based
   * Java RPC stack.
   *
   * @param bool $isInfinite
   */
  public function setIsInfinite($isInfinite)
  {
    $this->isInfinite = $isInfinite;
  }
  /**
   * @return bool
   */
  public function getIsInfinite()
  {
    return $this->isInfinite;
  }
  public function setValue($value)
  {
    $this->value = $value;
  }
  public function getValue()
  {
    return $this->value;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(ReportedParallelism::class, 'Google_Service_Dataflow_ReportedParallelism');
