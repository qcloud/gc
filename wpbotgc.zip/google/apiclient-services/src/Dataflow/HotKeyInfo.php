<?php
/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace Google\Service\Dataflow;

class HotKeyInfo extends \Google\Model
{
  /**
   * The age of the hot key measured from when it was first detected.
   *
   * @var string
   */
  public $hotKeyAge;
  /**
   * A detected hot key that is causing limited parallelism. This field will be
   * populated only if the following flag is set to true: "--
   * enable_hot_key_logging".
   *
   * @var string
   */
  public $key;
  /**
   * If true, then the above key is truncated and cannot be deserialized. This
   * occurs if the key above is populated and the key size is >5MB.
   *
   * @var bool
   */
  public $keyTruncated;

  /**
   * The age of the hot key measured from when it was first detected.
   *
   * @param string $hotKeyAge
   */
  public function setHotKeyAge($hotKeyAge)
  {
    $this->hotKeyAge = $hotKeyAge;
  }
  /**
   * @return string
   */
  public function getHotKeyAge()
  {
    return $this->hotKeyAge;
  }
  /**
   * A detected hot key that is causing limited parallelism. This field will be
   * populated only if the following flag is set to true: "--
   * enable_hot_key_logging".
   *
   * @param string $key
   */
  public function setKey($key)
  {
    $this->key = $key;
  }
  /**
   * @return string
   */
  public function getKey()
  {
    return $this->key;
  }
  /**
   * If true, then the above key is truncated and cannot be deserialized. This
   * occurs if the key above is populated and the key size is >5MB.
   *
   * @param bool $keyTruncated
   */
  public function setKeyTruncated($keyTruncated)
  {
    $this->keyTruncated = $keyTruncated;
  }
  /**
   * @return bool
   */
  public function getKeyTruncated()
  {
    return $this->keyTruncated;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(HotKeyInfo::class, 'Google_Service_Dataflow_HotKeyInfo');
