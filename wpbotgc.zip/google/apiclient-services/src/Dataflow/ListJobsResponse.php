<?php
/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace Google\Service\Dataflow;

class ListJobsResponse extends \Google\Collection
{
  protected $collection_key = 'jobs';
  protected $failedLocationType = FailedLocation::class;
  protected $failedLocationDataType = 'array';
  protected $jobsType = Job::class;
  protected $jobsDataType = 'array';
  /**
   * Set if there may be more results than fit in this response.
   *
   * @var string
   */
  public $nextPageToken;

  /**
   * Zero or more messages describing the [regional endpoints]
   * (https://cloud.google.com/dataflow/docs/concepts/regional-endpoints) that
   * failed to respond.
   *
   * @param FailedLocation[] $failedLocation
   */
  public function setFailedLocation($failedLocation)
  {
    $this->failedLocation = $failedLocation;
  }
  /**
   * @return FailedLocation[]
   */
  public function getFailedLocation()
  {
    return $this->failedLocation;
  }
  /**
   * A subset of the requested job information.
   *
   * @param Job[] $jobs
   */
  public function setJobs($jobs)
  {
    $this->jobs = $jobs;
  }
  /**
   * @return Job[]
   */
  public function getJobs()
  {
    return $this->jobs;
  }
  /**
   * Set if there may be more results than fit in this response.
   *
   * @param string $nextPageToken
   */
  public function setNextPageToken($nextPageToken)
  {
    $this->nextPageToken = $nextPageToken;
  }
  /**
   * @return string
   */
  public function getNextPageToken()
  {
    return $this->nextPageToken;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(ListJobsResponse::class, 'Google_Service_Dataflow_ListJobsResponse');
